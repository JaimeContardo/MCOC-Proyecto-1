#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 28 13:55:40 2018

@author: jose
"""

# -*- coding: utf-8 -*-
"""
Created on Sun Aug 26 17:30:11 2018

@author: herna
"""

import scipy as sp
from scipy.integrate import quad
from scipy import interpolate
import matplotlib.pyplot as plt
import linecache
import glob


def interpol(ruta,graficar=False):
	linea=linecache.getline(ruta, 2)
	print linea
	linea=linea[20:]
	dt=1./float(linea[:linea.find("m")])

	linea=linecache.getline(ruta, 3)

	n=int(linea[28:])

	a=sp.loadtxt(ruta,comments='#')


	t=sp.arange(0,dt*n,dt)
	try:
		i=interpolate.interp1d(t,a,kind='cubic')
	except:
		an=sp.zeros(len(a))
		an=a[0:-1]
		a=an
        
        i=interpolate.interp1d(t,a,kind='cubic')
	inter=i(t)

	if graficar:
		plt.plot(t,a,'o',t,inter,'-')
		plt.show()

	amax=max(abs(a))

	return i,amax,a,t